# Guía de Uso del Script Mejorado v10.0

## 🎯 Visión General

El script ahora tiene **DOS funcionalidades independientes**:

| Botón | Color | Función | Dónde Aparece |
|-------|-------|---------|---------------|
| **⬚** | Azul | Overlay Local en Navegador | Esquina inferior derecha de cada partido |
| **▶** | Naranja | Enviar a App WPF | Esquina inferior derecha de cada partido |

## 🎮 Guía de Uso

### 1. Overlay Local (Botón Azul ⬚)

#### Crear un Overlay
```
1. Ir a Flashscore.es (en vivo)
2. Buscar un partido
3. Hacer clic en el botón AZUL (⬚) en la esquina del partido
4. Se abre una ventana flotante en el navegador
```

#### En el Overlay
- **Agregar Partidos**: Clic en ⬚ de otros partidos → se agregan al mismo overlay
- **Agrupar por Liga**: Los partidos se organizan automáticamente bajo encabezados de liga
- **Mover Overlay**: Arrastra desde el encabezado "⚽ Flashscore Overlay"
- **Abrir Partido**: Doble clic en un partido → abre en nueva ventana
- **Quitar Partido**: Clic derecho en un partido → lo elimina
- **Cerrar Overlay**: Clic en "✕" en la esquina superior derecha

#### Ejemplo Visual
```
┌─────────────────────────────────────┐
│ ⚽ Flashscore Overlay          [✕]  │  ← Encabezado (arrastra aquí)
├─────────────────────────────────────┤
│ LA LIGA - ESPAÑA                    │  ← Agrupación por Liga
│ ┌───────────────────────────────────┤
│ │ Barcelona    2 - 1    Real Madrid │
│ │ Atlético     1 - 0    Sevilla     │
│                                      │
│ SERIE A - ITALIA                    │  ← Otra Liga
│ ┌───────────────────────────────────┤
│ │ AC Milan     3 - 2    Inter       │
│ │ Juve         2 - 2    Napoli      │
└─────────────────────────────────────┘
```

### 2. Envío a WPF (Botón Naranja ▶)

#### Enviar Partido a la App WPF
```
1. Tener la App WPF abierta en tu PC
2. En Flashscore.es, buscar un partido
3. Hacer clic en el botón NARANJA (▶) 
4. El partido aparece en la ventana WPF
5. Se muestra notificación verde: "✓ Enviado a WPF App"
```

#### Estados Posibles
```
✓ Enviado a WPF App        → Verde (éxito)
✗ Error al enviar          → Rojo (problema de conexión)
WPF no disponible          → Naranja (app cerrada o no responde)
```

#### Requisitos
- App WPF abierta y ejecutándose
- Conectada en localhost:8765
- El script verifica automáticamente cada 10 segundos

## 🔧 Instalación del Script

### Pasos
1. Instalar [Tampermonkey](https://www.tampermonkey.net/) en tu navegador
2. Crear nuevo script en Tampermonkey
3. Copiar el contenido de `TampermonkeyFlashscoreWPF.js`
4. Guardar y asegurarse que esté activado
5. Recargar Flashscore.es

### Verificación
- Deberías ver notificación de conexión al cargar Flashscore
- Si dice "✓ Conectado a WPF" → Todo OK
- Si dice "⚠ WPF App no disponible" → Abre la app WPF primero

## 📊 Flujo de Datos

### Opción 1: Overlay Local (Sin necesidad de WPF)
```
Flashscore.es
    ↓ (clic botón azul)
Overlay Local en Navegador
    ↓ (mostrar datos)
Usuario ve partidos organizados por liga
```

### Opción 2: Envío a WPF (Para monitor separado)
```
Flashscore.es
    ↓ (clic botón naranja)
HTTP POST → localhost:8765/api/match
    ↓ (recibe)
App WPF
    ↓ (renderiza)
Ventana WPF con partido
```

### Opción 3: Ambos Simultáneamente
```
Puedes usar overlay local mientras envías otros partidos a WPF
Sin conflictos ni interferencias
```

## 🎨 Personalización

### Cambiar Colores
En el script, busca:
```javascript
// Botón azul (overlay local)
background-color: #007bff;  // Cámbialo aquí

// Botón naranja (WPF)
background-color: #ff6b35;  // Cámbialo aquí
```

### Cambiar Posición del Overlay
```javascript
// En createOverlay():
const overlay = document.createElement('div');
overlay.style.top = '60px';   // Cámbialo
overlay.style.left = '60px';  // Cámbialo
```

### Cambiar Tamaño Mínimo
```javascript
// En estilos:
.fc-overlay {
    min-width: 420px;   // Ancho mínimo
    max-width: 600px;   // Ancho máximo
    max-height: 80vh;   // Alto máximo
}
```

## 🐛 Solución de Problemas

| Problema | Causa | Solución |
|----------|-------|----------|
| No veo los botones | Script no activado | Activar en Tampermonkey |
| Botón naranja no funciona | WPF no abierto | Abrir la app WPF primero |
| Overlay muy pequeño | Página sobrecargada | Actualizar la página |
| Texto se corta | Navegador zoom al 125%+ | Bajar zoom a 100% |
| Script lento | Muchos partidos cargados | Cerrar overlay si no lo usas |

## 📱 Recomendaciones de Setup

### Para Transmisiones (Dual Monitor)
```
Monitor 1 (Principal):     Flashscore.es + Overlay Local
Monitor 2 (Secundario):    App WPF
O usar navegador en ventana pequeña + WPF en ventana grande
```

### Para Móvil/Tablet
```
Solo funciona overlay local (no hay WPF en móvil)
El script detecta automáticamente la disponibilidad
```

### Para Streaming
```
1. Abre Flashscore en navegador (monitor 1)
2. Abre WPF en monitor 2
3. Usa botón naranja para enviar partidos principales
4. Usa overlay azul para ver muchos partidos a la vez
```

## 🚀 Características Avanzadas

### Z-Index Management
```javascript
// Los overlays siempre se traen al frente automáticamente
bringToFront(overlay)
// Al hacer clic en cualquier overlay se pone en el tope
```

### MutationObserver
```javascript
// El script vigila cambios en la página automáticamente
// Nuevos partidos que aparecen reciben botones automáticamente
// Sin necesidad de recargar
```

### Reconnection Logic
```javascript
// Se conecta a WPF cada 10 segundos
// Si la app se abre después, se detecta automáticamente
// No necesita recargar la página
```

## 📝 Notas Importantes

1. **El script no consume recursos significativos**
   - Usa MutationObserver eficiente
   - Limpia referencias automáticamente

2. **Los botones se agregan automáticamente a nuevos partidos**
   - Verificación cada 2 segundos
   - Compatible con secciones desplegables

3. **No interfiere con Flashscore normal**
   - Solo agrega botones
   - No cambia funcionalidad original

4. **Los datos se envían vía JSON**
   - HTML del partido
   - Nombre de la liga
   - Enlace del partido

## 🔐 Privacidad y Seguridad

- ✅ Comunicación solo en localhost (no sube a internet)
- ✅ Datos no se guardan en servidor
- ✅ Script no accede a datos sensibles
- ✅ Compatible con CORS

---

**¿Preguntas?** Revisa el código comentado en `TampermonkeyFlashscoreWPF.js`

**Versión**: v10.0
**Última Actualización**: 2024
