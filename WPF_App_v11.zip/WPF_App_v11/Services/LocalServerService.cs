using System;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace WPFApp.Services
{
    public class LocalServerService : IDisposable
    {
        private HttpListener? _listener;
        private CancellationTokenSource? _cts;
        private bool _disposed = false;
        public bool IsRunning { get; private set; } = false;
        public event EventHandler<MatchDataEventArgs>? OnMatchDataReceived;

        public class MatchDataEventArgs : EventArgs
        {
            public string Team1 { get; set; } = "";
            public string Team2 { get; set; } = "";
            public string Logo1 { get; set; } = "";
            public string Logo2 { get; set; } = "";
            public string Score1 { get; set; } = "";
            public string Score2 { get; set; } = "";
            public string Status { get; set; } = "";
            public string LeagueName { get; set; } = "";
            public string MatchLink { get; set; } = "";
            public string CountryCode { get; set; } = "";
            public string Sport { get; set; } = "football";
        }

        public async Task<bool> StartAsync()
        {
            Stop();
            await Task.Delay(200);
            int[] ports = { 8765, 8766, 8767, 8768 };
            foreach (int port in ports)
            {
                if (await TryStartOnPort(port))
                {
                    IsRunning = true;
                    return true;
                }
            }
            Application.Current?.Dispatcher.Invoke(() =>
                MessageBox.Show("No se pudo iniciar el servidor en ningún puerto (8765-8768).\nEjecuta la app como administrador.",
                    "Error servidor", MessageBoxButton.OK, MessageBoxImage.Error));
            return false;
        }

        private async Task<bool> TryStartOnPort(int port)
        {
            try
            {
                _cts = new CancellationTokenSource();
                _listener = new HttpListener();
                _listener.Prefixes.Add($"http://127.0.0.1:{port}/");
                _listener.Prefixes.Add($"http://localhost:{port}/");
                _listener.Start();
                Port = port;
                _ = HandleLoop(_cts.Token);
                await Task.Delay(100);
                using var client = new System.Net.Sockets.TcpClient();
                await client.ConnectAsync("127.0.0.1", port);
                client.Close();
                Console.WriteLine($"[Server] Activo en puerto {port}");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Server] Puerto {port} fallido: {ex.Message}");
                try { _listener?.Stop(); _listener?.Close(); } catch { }
                _listener = null;
                return false;
            }
        }

        public int Port { get; private set; } = 8765;

        public void Stop()
        {
            try { _cts?.Cancel(); } catch { }
            try { _listener?.Stop(); _listener?.Close(); } catch { }
            _listener = null;
            IsRunning = false;
        }

        private async Task HandleLoop(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    var ctx = await _listener!.GetContextAsync().WaitAsync(ct);
                    _ = Task.Run(() => Handle(ctx));
                }
                catch (OperationCanceledException) { break; }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Server] Loop error: {ex.Message}");
                    break;
                }
            }
            IsRunning = false;
        }

        private void Handle(HttpListenerContext ctx)
        {
            try
            {
                var req = ctx.Request;
                var resp = ctx.Response;
                resp.Headers.Set("Access-Control-Allow-Origin", "*");
                resp.Headers.Set("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
                resp.Headers.Set("Access-Control-Allow-Headers", "Content-Type");
                if (req.HttpMethod == "OPTIONS") { resp.StatusCode = 200; resp.Close(); return; }
                if (req.HttpMethod == "GET" && req.Url!.LocalPath == "/health")
                { Send(resp, 200, "{\"ok\":true}"); return; }
                if (req.HttpMethod == "POST" && req.Url!.LocalPath == "/api/match")
                { HandleMatch(req, resp); return; }
                Send(resp, 404, "{\"error\":\"not found\"}");
            }
            catch (Exception ex) { Console.WriteLine($"[Server] Handle error: {ex.Message}"); }
        }

        private void HandleMatch(HttpListenerRequest req, HttpListenerResponse resp)
        {
            try
            {
                string body;
                using (var r = new System.IO.StreamReader(req.InputStream, Encoding.UTF8))
                    body = r.ReadToEnd();
                Console.WriteLine($"[Server] Recibido: {body[..Math.Min(200, body.Length)]}");
                using var doc = JsonDocument.Parse(body);
                var root = doc.RootElement;
                var args = new MatchDataEventArgs
                {
                    Team1 = Get(root, "team1"),
                    Team2 = Get(root, "team2"),
                    Logo1 = Get(root, "logo1"),
                    Logo2 = Get(root, "logo2"),
                    Score1 = Get(root, "score1"),
                    Score2 = Get(root, "score2"),
                    Status = Get(root, "status"),
                    LeagueName = Get(root, "leagueName"),
                    MatchLink = Get(root, "matchLink"),
                    CountryCode = Get(root, "countryCode"),
                    Sport = Get(root, "sport").Length > 0 ? Get(root, "sport") : "football",
                };
                Console.WriteLine($"[Server] Partido: {args.Team1} vs {args.Team2} | {args.Sport} | {args.CountryCode}");
                OnMatchDataReceived?.Invoke(this, args);
                Send(resp, 200, "{\"ok\":true}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Server] HandleMatch error: {ex.Message}");
                Send(resp, 500, "{\"error\":\"" + ex.Message + "\"}");
            }
        }

        private static string Get(JsonElement root, string key)
        {
            foreach (var p in root.EnumerateObject())
                if (string.Equals(p.Name, key, StringComparison.OrdinalIgnoreCase))
                    return p.Value.ValueKind == JsonValueKind.String ? p.Value.GetString() ?? "" : p.Value.ToString();
            return "";
        }

        private static void Send(HttpListenerResponse resp, int code, string body)
        {
            try
            {
                resp.StatusCode = code;
                resp.ContentType = "application/json; charset=utf-8";
                var buf = Encoding.UTF8.GetBytes(body);
                resp.ContentLength64 = buf.Length;
                resp.OutputStream.Write(buf, 0, buf.Length);
                resp.OutputStream.Close();
            }
            catch { }
        }

        public void Dispose() { if (!_disposed) { Stop(); _disposed = true; } }
    }
}
