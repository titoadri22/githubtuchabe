# 🏟️ Guía de Integración: Tampermonkey + WPF App (Flashscore Overlay)

## 📋 Resumen
Este sistema conecta tu script de Tampermonkey en Flashscore.es con una aplicación WPF local (.NET 6) para mostrar overlays de partidos deportivos en una ventana flotante independiente en Windows 10.

---

## 🛠️ Requisitos Previos
1. **WPF App compilada y ejecutándose** en `c:\Users\tupu\Documents\andr\WPF App`
2. **Tampermonkey** instalado en el navegador
3. **Firefox** o **Chrome** (cualquier navegador con soporte a Tampermonkey)
4. **Windows 10** (.NET 6 runtime instalado)

---

## 📦 Componentes del Sistema

### 1. **Servidor HTTP Local (WPF)**
- **Puerto**: `8765`
- **Dirección**: `http://localhost:8765`
- **Endpoints**:
  - `POST /api/match` - Recibe datos del partido
  - `GET /health` - Verifica conexión
  - `OPTIONS` - Soporte CORS

### 2. **Script Tampermonkey**
- **Nombre**: "Flashscore Overlay - WPF Integration"
- **Función**: Añade botón naranja (▶) en cada partido
- **Al hacer clic**: Envía el HTML del partido al servidor WPF

### 3. **Ventana WPF (OverlayWindow)**
- **Visualización**: WebView2 con HTML renderizado
- **Actualización**: En tiempo real cuando recibe datos
- **Funcionalidad**: Arrastradera, redimensionable, siempre al frente

---

## 🚀 Instalación y Uso

### Paso 1: Instalar el Script de Tampermonkey

1. Abre **Tampermonkey** en tu navegador
2. Clic en el ícono de Tampermonkey → "Crear un nuevo script"
3. **Copia y pega** el contenido de [TampermonkeyFlashscoreWPF.js](./Scripts/TampermonkeyFlashscoreWPF.js)
4. **Guarda** el script (Ctrl+S)
5. Verifica que esté **habilitado** en el dashboard de Tampermonkey

### Paso 2: Ejecutar la Aplicación WPF

```powershell
cd "c:\Users\tupu\Documents\andr\WPF App"
& "C:\Program Files\dotnet\dotnet.exe" run
```

O simplemente abre la solución en Visual Studio y presiona **F5**.

### Paso 3: Usar el Sistema

1. **Abre Flashscore.es** en tu navegador
2. Deberías ver una notificación: **"✓ Conectado a WPF"**
3. En cada partido aparecerá un **botón naranja (▶)** en la esquina inferior derecha
4. **Haz clic** en cualquier botón para enviar ese partido al overlay WPF
5. El overlay se abrirá automáticamente en primer plano

---

## 🎨 Características

### En el Navegador (Script Tampermonkey)
- ✅ Botón naranja flotante en cada partido
- ✅ Notificaciones de estado (verde = éxito, rojo = error)
- ✅ Verificación automática de conexión cada 10 segundos
- ✅ Limpieza automática del HTML (sin botones ni enlaces)
- ✅ Soporte CORS para comunicación con WPF

### En la Aplicación WPF
- ✅ Ventana flotante redimensionable
- ✅ Draggable (arrastradera)
- ✅ Siempre al frente (Topmost)
- ✅ WebView2 integrado para renderizar HTML
- ✅ Página de bienvenida con estado del servidor
- ✅ Actualización en tiempo real

---

## 📡 Flujo de Datos

```
Flashscore.es                  WPF App Local (Puerto 8765)      Ventana Overlay
    ↓                                    ↓                              ↓
Usuario hace clic           →  LocalServerService.cs        →   OverlayWindow
en botón ▶                        procesa POST                   (WebView2)
    ↓                                    ↓                              ↓
Script envía JSON          →  Eventos OnMatchDataReceived   →   DisplayMatchOverlay
(HTML, Liga, Link)              y levanta OverlayWindow           muestra HTML
```

---

## 🔧 Configuración Avanzada

### Cambiar Puerto del Servidor
1. En **LocalServerService.cs**, línea 19:
   ```csharp
   private const string LocalPort = "8765";  // Cambiar aquí
   ```

2. En **TampermonkeyFlashscoreWPF.js**, línea 9:
   ```javascript
   const WPF_SERVER = 'http://localhost:8765';  // Cambiar aquí
   ```

### Cambiar Estilo del Overlay
En **OverlayWindow.xaml.cs**, método `DisplayMatchOverlay()`, modifica el HTML CSS.

### Cambiar Posición Inicial de la Ventana
En **OverlayWindow.xaml.cs**, línea 23-24:
```csharp
this.Left = 100;   // Píxeles desde la izquierda
this.Top = 100;    // Píxeles desde arriba
```

---

## 🐛 Solución de Problemas

### ❌ "✗ WPF no disponible"
1. Verifica que la aplicación WPF esté ejecutándose
2. Asegúrate de que el puerto 8765 no esté ocupado
3. Intenta hacer clic nuevamente (la conexión se verifica cada 10s)

### ❌ "✗ No se pudo conectar con WPF"
1. El servidor WPF no respondió a tiempo
2. Aumenta el timeout en `TampermonkeyFlashscoreWPF.js` (línea 77, `timeout: 5000`)
3. Revisa la consola del navegador (F12) para más detalles

### ❌ Overlay no se actualiza
1. Abre las Developer Tools del navegador (F12)
2. Revisa si hay errores de CORS
3. Verifica que LocalServerService está ejecutándose correctamente

### ❌ Puerto 8765 en uso
```powershell
# En PowerShell (Admin):
netstat -ano | findstr :8765
# Anota el PID y luego:
taskkill /PID <número> /F
```

---

## 📝 Estructura de Archivos

```
WPF App/
├── WPFApp.csproj                  # Configuración del proyecto
├── App.xaml                       # Aplicación principal
├── App.xaml.cs                    # Código-behind de App
├── OverlayWindow.xaml             # Interfaz de la ventana overlay
├── OverlayWindow.xaml.cs          # Lógica de OverlayWindow
├── Services/
│   └── LocalServerService.cs      # Servidor HTTP local
├── Scripts/
│   └── TampermonkeyFlashscoreWPF.js  # Script para navegador
├── bin/
│   └── Debug/
│       └── net6.0-windows/
│           └── WPFApp.dll         # Ejecutable compilado
└── obj/
    └── Debug/
        └── net6.0-windows/
```

---

## 🔐 Seguridad

- El servidor solo escucha en **localhost** (127.0.0.1)
- No se almacenan datos permanentemente
- CORS permitido solo para el navegador local
- Los datos del partido se procesan en memoria

---

## 📚 Referencias Técnicas

### APIs Utilizadas
- **HttpListener** (.NET Framework): Servidor HTTP simple
- **WebView2**: Control para renderizar HTML en WPF
- **JSON Serialization**: Para comunicación de datos
- **Async/Await**: Para operaciones asincrónicas

### Namespaces Importados
```csharp
System.Net;           // HttpListener, HttpListenerContext
System.Text;          // Encoding, StringBuilder
System.Text.Json;     // JsonSerializer
System.Threading;     // CancellationToken
System.Threading.Tasks;
Microsoft.Web.WebView2.Wpf;
Microsoft.Web.WebView2.Core;
```

---

## ✅ Checklist de Funcionamiento

- [ ] .NET 6 SDK instalado (`dotnet --version`)
- [ ] Proyecto compilado sin errores
- [ ] Aplicación WPF en ejecución
- [ ] Script Tampermonkey instalado y habilitado
- [ ] Notificación "✓ Conectado a WPF" visible en Flashscore.es
- [ ] Botón naranja (▶) visible en cada partido
- [ ] Al hacer clic, el overlay se abre en la aplicación WPF
- [ ] HTML del partido se muestra correctamente

---

## 🎯 Próximas Mejoras Posibles

1. **Base de datos local** para guardar histórico de partidos
2. **WebSocket** para actualización bidireccional en tiempo real
3. **Notificaciones** cuando comienza un partido favorito
4. **Filtros** por liga, equipo o hora
5. **Integración con APIs** de Flashscore (estadísticas en vivo)
6. **Tema oscuro/claro** configurable

---

## 📧 Soporte

Si tienes problemas:
1. Revisa la consola del navegador (F12)
2. Revisa los logs de .NET en Visual Studio
3. Verifica los puertos y firewall
4. Recarga el script de Tampermonkey

---

**Versión**: 8.0  
**Última actualización**: 23/01/2026  
**Estado**: ✅ Operacional
