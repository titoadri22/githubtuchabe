using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;
using WPFApp.Services;

namespace WPFApp
{
    public class MatchModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string League { get; set; } = "TORNEO";
        public string Country { get; set; } = "";
        public string CountryCode { get; set; } = "";
        public string Sport { get; set; } = "football";
        public string Team1 { get; set; } = "Local";
        public string Team2 { get; set; } = "Visitante";
        public string Logo1 { get; set; } = "";
        public string Logo2 { get; set; } = "";
        public int Score1 { get; set; } = 0;
        public int Score2 { get; set; } = 0;
        public bool IsLive { get; set; } = false;
        public bool IsFinished { get; set; } = false;
        public bool IsHT { get; set; } = false;
        public bool IsScheduled { get; set; } = false;
        public string StatusRaw { get; set; } = "";
        public int ElapsedSeconds { get; set; } = 0;
        public int ExtraTimeBase { get; set; } = 0; // 0=normal, 45=tiempo extra 1ª, 90=tiempo extra 2ª
        public bool TimerRunning { get; set; } = false;
        public string MatchLink { get; set; } = "";

        public string TimeClass
        {
            get
            {
                if (IsFinished) return "ft";
                if (IsHT) return "ht";
                if (IsScheduled) return "sched";
                if (IsLive) return "live";
                return "sched";
            }
        }
    }

    public partial class OverlayWindow : Window
    {
        private readonly object _matchesLock = new();
        private readonly List<MatchModel> _matches = new();
        private System.Windows.Threading.DispatcherTimer _timer = null!;
        private bool _initialized = false;
        private bool _renderPending = false;

        public OverlayWindow(LocalServerService? server = null)
        {
            InitializeComponent();
            this.Left = 80; this.Top = 80;
            _timer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _timer.Tick += Timer_Tick;
            _timer.Start();
            _ = InitWebView();
        }

        private async System.Threading.Tasks.Task InitWebView()
        {
            try
            {
                var env = await CoreWebView2Environment.CreateAsync(
                    userDataFolder: System.IO.Path.Combine(
                        System.IO.Path.GetTempPath(),
                        "WPFApp_wv2_" + Guid.NewGuid().ToString("N").Substring(0, 8)));
                await webView.EnsureCoreWebView2Async(env);
                webView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
                webView.CoreWebView2.Settings.AreDevToolsEnabled = false;
                webView.CoreWebView2.WebMessageReceived += OnMessage;
                var tcs = new System.Threading.Tasks.TaskCompletionSource<bool>();
                webView.CoreWebView2.DOMContentLoaded += (s, e) => tcs.TrySetResult(true);
                webView.NavigateToString(BasePage);
                await tcs.Task;
                _initialized = true;
                await JS("renderAll([])");
            }
            catch (Exception ex) { MessageBox.Show($"Error WebView2: {ex.Message}"); }
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            bool changed = false;
            lock (_matchesLock)
            {
                foreach (var m in _matches)
                    if (m.IsLive && m.TimerRunning && !m.IsFinished && !m.IsHT)
                    { m.ElapsedSeconds++; changed = true; }
            }
            if (changed && _initialized) _ = PushTimers();
        }

        private static string CalcNumPart(MatchModel m)
        {
            int mins = m.ElapsedSeconds / 60;
            if (m.ExtraTimeBase == 90 || mins > 90) return "90+" + (mins - 90);
            if (m.ExtraTimeBase == 45 && mins > 45) return "45+" + (mins - 45);
            if (mins >= 90) return "90+";
            return mins.ToString();
        }

        private async System.Threading.Tasks.Task PushTimers()
        {
            var sb = new StringBuilder("(function(){");
            lock (_matchesLock)
            {
                foreach (var m in _matches.Where(x => x.IsLive && !x.IsFinished && !x.IsHT))
                {
                    string numPart = CalcNumPart(m);
                    sb.Append("var n=document.getElementById('tn_" + m.Id + "');if(n)n.textContent='" + numPart + "';");
                }
            }
            sb.Append("})()");
            await JS(sb.ToString());
        }

        public void AddMatch(LocalServerService.MatchDataEventArgs e)
        {
            var m = BuildModel(e);
            lock (_matchesLock) { _matches.Insert(0, m); }
            if (_initialized) _ = PushFullRender();
        }

        private static bool IsHalfTime(string status)
        {
            if (string.IsNullOrEmpty(status)) return false;
            var s = status.ToUpperInvariant().Trim();
            return s == "HT" || s == "HALF TIME" || s == "HALFTIME" ||
                   s == "HALF-TIME" || s == "DESCANSO" || s == "PAUSE" || s == "BREAK";
        }

        private static MatchModel BuildModel(LocalServerService.MatchDataEventArgs e)
        {
            var m = new MatchModel
            {
                Team1 = e.Team1.Trim().Length > 0 ? e.Team1.Trim() : "Local",
                Team2 = e.Team2.Trim().Length > 0 ? e.Team2.Trim() : "Visitante",
                Logo1 = e.Logo1.Trim(),
                Logo2 = e.Logo2.Trim(),
                MatchLink = e.MatchLink.Trim(),
                CountryCode = (e.CountryCode ?? "").Trim().ToLower(),
                Sport = (e.Sport ?? "football").Trim().ToLower(),
            };

            string lg = (e.LeagueName ?? "").Trim().ToUpper();
            if (lg.Contains(" - "))
            {
                var p = lg.Split(new[] { " - " }, 2, StringSplitOptions.None);
                m.Country = p[0].Trim();
                m.League = p[1].Trim();
            }
            else { m.Country = ""; m.League = lg.Length > 0 ? lg : "TORNEO"; }

            if (int.TryParse(e.Score1?.Trim(), out int s1)) m.Score1 = s1;
            if (int.TryParse(e.Score2?.Trim(), out int s2)) m.Score2 = s2;

            string status = (e.Status ?? "").Trim();
            m.StatusRaw = status;

            // 1. Finalizado
            if (status == "FT" || status == "AET" || status == "Pen." || status == "Finished")
            {
                m.IsFinished = true;
            }
            // 2. Descanso
            else if (IsHalfTime(status))
            {
                m.IsLive = true; m.IsHT = true;
                m.ElapsedSeconds = 45 * 60;
            }
            // 3. Tiempo extra: "90+10" o "45+2" (con o sin apóstrofe)
            else if (System.Text.RegularExpressions.Regex.IsMatch(status, @"^\d+\+\d+'?$"))
            {
                var xm = System.Text.RegularExpressions.Regex.Match(status, @"^(\d+)\+(\d+)");
                if (xm.Success
                    && int.TryParse(xm.Groups[1].Value, out int xBase)
                    && int.TryParse(xm.Groups[2].Value, out int xExtra))
                {
                    m.IsLive = true; m.TimerRunning = true;
                    m.ElapsedSeconds = (xBase + xExtra) * 60;
                    m.ExtraTimeBase = xBase >= 90 ? 90 : 45;
                }
            }
            // 4. Minuto normal: "77" o "77'"
            else if (System.Text.RegularExpressions.Regex.IsMatch(status, @"^\d{1,3}'?$"))
            {
                var mm = System.Text.RegularExpressions.Regex.Match(status, @"^(\d+)");
                if (mm.Success && int.TryParse(mm.Groups[1].Value, out int mins) && mins > 0)
                {
                    m.IsLive = true; m.TimerRunning = true;
                    m.ElapsedSeconds = mins * 60;
                }
                else { m.IsScheduled = true; }
            }
            // 5. Hora programada: "18:30"
            else if (System.Text.RegularExpressions.Regex.IsMatch(status, @"^\d{1,2}:\d{2}$"))
            {
                m.IsScheduled = true;
            }
            // 6. Resto con goles → en vivo; sin goles → programado
            else if (status.Length > 0)
            {
                if (s1 > 0 || s2 > 0) { m.IsLive = true; m.TimerRunning = true; m.StatusRaw = "LIVE"; }
                else { m.IsScheduled = true; }
            }
            else { m.IsScheduled = true; }

            return m;
        }

        private async System.Threading.Tasks.Task PushFullRender()
        {
            if (_renderPending) return;
            _renderPending = true;
            try { await JS("renderAll(" + BuildJson() + ")"); }
            finally { _renderPending = false; }
        }

        private string BuildJson()
        {
            List<MatchModel> snapshot;
            lock (_matchesLock) { snapshot = _matches.ToList(); }
            var groups = snapshot.GroupBy(m => m.Country + "||" + m.League).ToList();
            var sb = new StringBuilder("[");
            foreach (var g in groups)
            {
                var parts = g.Key.Split(new[] { "||" }, StringSplitOptions.None);
                var first = g.First();
                sb.Append("{");
                sb.Append("\"country\":\"" + Esc(parts[0]) + "\",");
                sb.Append("\"league\":\"" + Esc(parts[1]) + "\",");
                sb.Append("\"countryCode\":\"" + Esc(first.CountryCode) + "\",");
                sb.Append("\"sport\":\"" + Esc(first.Sport) + "\",");
                sb.Append("\"matches\":[");
                foreach (var m in g)
                {
                    string numPart;
                    if (m.IsFinished) numPart = "FT";
                    else if (m.IsHT) numPart = "DESCANSO";
                    else if (m.IsScheduled) numPart = Esc(m.StatusRaw);
                    else if (!m.IsLive) numPart = Esc(m.StatusRaw);
                    else numPart = CalcNumPart(m);

                    sb.Append("{");
                    sb.Append("\"id\":\"" + m.Id + "\",");
                    sb.Append("\"team1\":\"" + Esc(m.Team1) + "\",");
                    sb.Append("\"team2\":\"" + Esc(m.Team2) + "\",");
                    sb.Append("\"logo1\":\"" + Esc(m.Logo1) + "\",");
                    sb.Append("\"logo2\":\"" + Esc(m.Logo2) + "\",");
                    sb.Append("\"score1\":" + m.Score1 + ",");
                    sb.Append("\"score2\":" + m.Score2 + ",");
                    sb.Append("\"showScore\":" + ((m.IsLive || m.IsFinished || m.IsHT) ? "true" : "false") + ",");
                    sb.Append("\"isLive\":" + (m.IsLive && !m.IsHT && !m.IsFinished ? "true" : "false") + ",");
                    sb.Append("\"timeNum\":\"" + numPart + "\",");
                    sb.Append("\"tc\":\"" + m.TimeClass + "\"");
                    sb.Append("},");
                }
                if (sb[^1] == ',') sb.Length--;
                sb.Append("]},");
            }
            if (sb.Length > 1 && sb[^1] == ',') sb.Length--;
            sb.Append("]");
            return sb.ToString();
        }

        private void OnMessage(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                string msg = e.TryGetWebMessageAsString();
                Dispatcher.Invoke(() =>
                {
                    if (msg == "close") { Close(); return; }
                    if (msg == "clear") { lock (_matchesLock) { _matches.Clear(); } _ = PushFullRender(); return; }
                    if (msg.StartsWith("remove:")) { lock (_matchesLock) { _matches.RemoveAll(x => x.Id == msg[7..]); } _ = PushFullRender(); }
                    else if (msg.StartsWith("open:"))
                    {
                        string url = msg[5..];
                        if (!string.IsNullOrEmpty(url))
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url) { UseShellExecute = true });
                    }
                });
            }
            catch { }
        }

        private async System.Threading.Tasks.Task JS(string script)
        { try { await webView.CoreWebView2.ExecuteScriptAsync(script); } catch { } }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        { _timer?.Stop(); try { webView?.Dispose(); } catch { } }

        private static string Esc(string s) => (s ?? "")
            .Replace("\\", "\\\\").Replace("\"", "\\\"")
            .Replace("\r", "").Replace("\n", "").Replace("'", "\\'");

        private const string BasePage = @"<!DOCTYPE html>
<html lang='es'>
<head><meta charset='UTF-8'><style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;overflow:hidden;background:#1a1f27;color:#d4d4d4;
  font-family:'Roboto Condensed','Arial Narrow',Arial,sans-serif;font-size:13px}
.bar{height:38px;background:#0f1319;border-bottom:2px solid #e8463c;
  display:flex;align-items:center;justify-content:space-between;
  padding:0 12px;flex-shrink:0;user-select:none}
.brand{font-size:17px;font-weight:900;color:#fff}
.bs{color:#e8463c}
.bar-r{display:flex;align-items:center;gap:6px}
.cnt{color:#555;font-size:11px;margin-right:4px}
.btn{background:transparent;border:none;color:#555;font-size:13px;cursor:pointer;
  width:26px;height:26px;border-radius:3px;display:flex;align-items:center;
  justify-content:center;transition:.15s}
.btn:hover{background:#2a3040;color:#bbb}
.cls:hover{background:#8b0000;color:#fff}
.list{height:calc(100vh - 38px);overflow-y:auto}
.list::-webkit-scrollbar{width:4px}
.list::-webkit-scrollbar-thumb{background:#2a3040;border-radius:2px}
.lh{height:26px;background:#0f1319;display:flex;align-items:center;
  padding:0 10px;border-left:3px solid #e8463c;border-bottom:1px solid #070a0f;gap:4px}
.lh-flag{font-size:13px;flex-shrink:0}
.lh-c{color:#999;font-size:10px;font-weight:700;text-transform:uppercase}
.lh-sep{color:#333;margin:0 2px;font-size:10px}
.lh-n{color:#c0c8d8;font-size:10px;font-weight:700;text-transform:uppercase;
  flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lh-sport{font-size:10px;opacity:.4;flex-shrink:0}
.mr{display:flex;align-items:center;padding:6px 10px;background:#1a1f27;
  border-bottom:1px solid #111720;position:relative;min-height:50px;transition:background .1s}
.mr:hover{background:#1e2530}
.tc{width:70px;flex-shrink:0;display:flex;flex-direction:column;align-items:center;justify-content:center}
.mt-wrap{display:flex;align-items:baseline;justify-content:center;gap:0}
.mt-num{font-size:13px;font-weight:700;color:#e8463c}
.mt-apos{font-size:13px;font-weight:700;color:#e8463c;animation:bl 1.2s ease-in-out infinite}
.ht-label{font-size:10px;font-weight:700;color:#e8463c;text-align:center;
  text-transform:uppercase;animation:bl 1.2s ease-in-out infinite;width:68px}
.ft-label{font-size:11px;font-weight:600;color:#5a6070;text-align:center}
.sched-label{font-size:12px;font-weight:600;color:#e8463c;text-align:center}
@keyframes bl{0%,100%{opacity:1}50%{opacity:.15}}
.teams{flex:1;display:flex;flex-direction:column;gap:5px;padding:0 8px;overflow:hidden}
.team{display:flex;align-items:center;gap:6px;overflow:hidden}
.lgo{width:18px;height:18px;object-fit:contain;flex-shrink:0}
.lgo-ph{width:18px;height:18px;background:#252d3a;border-radius:50%;flex-shrink:0}
.tn{font-size:13px;font-weight:400;color:#c8cdd6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sc-col{width:28px;flex-shrink:0;display:flex;flex-direction:column;align-items:center;gap:4px}
.sc-live{font-size:15px;font-weight:800;color:#e8463c;line-height:1;text-align:center;width:100%}
.sc-ft{font-size:15px;font-weight:800;color:#9a9a9a;line-height:1;text-align:center;width:100%}
.sc-ph{color:#2a3040;font-size:13px;line-height:1;text-align:center}
.del{position:absolute;right:0;top:0;bottom:0;width:20px;display:flex;
  align-items:center;justify-content:center;color:#1a1f27;font-size:14px;
  opacity:0;transition:.15s;cursor:pointer}
.mr:hover .del{opacity:1}.del:hover{background:#8b0000;color:#fff}
.empty{color:#252d3a;text-align:center;padding:60px 20px;font-size:12px;line-height:2.4}
</style></head>
<body>
<div class='bar'>
  <div class='brand'>Flash<span class='bs'>score</span></div>
  <div class='bar-r'>
    <span class='cnt' id='cnt'>0 partidos</span>
    <button class='btn' onclick='send(""clear"")' title='Limpiar'>&#x1F5D1;</button>
    <button class='btn cls' onclick='send(""close"")' title='Cerrar'>&#x2715;</button>
  </div>
</div>
<div class='list' id='list'>
  <div class='empty'>&#x26A1; Pulsa &#x25B6; en Flashscore para anadir partidos</div>
</div>
<script>
function send(m){window.chrome.webview.postMessage(m);}
function rm(id){window.chrome.webview.postMessage('remove:'+id);}
function mkLogo(url,cls){
  if(!url) return '<div class=""'+cls+'-ph""></div>';
  return '<img class=""'+cls+'"" src=""'+url+'"" onerror=""this.style.display=\'none\'""/>';
}
function countryFlag(code){
  if(!code||code.length<2) return '';
  if(code==='gb-eng') return '\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F';
  if(code==='gb-sct') return '\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74\uDB40\uDC7F';
  if(code==='gb-wls') return '\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73\uDB40\uDC7F';
  var cc=code.substring(0,2).toUpperCase();
  if(cc.charCodeAt(0)<65||cc.charCodeAt(0)>90) return '';
  return String.fromCodePoint(0x1F1E0+cc.charCodeAt(0)-65)+
         String.fromCodePoint(0x1F1E0+cc.charCodeAt(1)-65);
}
function sportIcon(sport){
  var icons={'football':'&#x26BD;','basketball':'&#x1F3C0;','tennis':'&#x1F3BE;',
    'hockey':'&#x1F3D2;','volleyball':'&#x1F3D0;','baseball':'&#x26BE;',
    'rugby':'&#x1F3C9;','american-football':'&#x1F3C8;','handball':'&#x1F93E;','futsal':'&#x26BD;'};
  return icons[sport]||'&#x1F3C6;';
}
function buildTime(m){
  if(m.tc==='ht')    return '<div class=""ht-label"">DESCANSO</div>';
  if(m.tc==='ft')    return '<div class=""ft-label"">FT</div>';
  if(m.tc==='sched') return '<div class=""sched-label"">'+(m.timeNum||'--')+'</div>';
  return '<div class=""mt-wrap""><span class=""mt-num"" id=""tn_'+m.id+'"">'+m.timeNum+'</span><span class=""mt-apos"">\'</span></div>';
}
function renderAll(groups){
  var total=0,html='';
  if(!groups||groups.length===0){
    html='<div class=""empty"">&#x26A1; Pulsa &#x25B6; en Flashscore para anadir partidos</div>';
  } else {
    for(var i=0;i<groups.length;i++){
      var g=groups[i];
      var flag=countryFlag(g.countryCode||'');
      var icon=sportIcon(g.sport||'football');
      html+='<div><div class=""lh"">';
      if(flag) html+='<span class=""lh-flag"">'+flag+'</span>';
      if(g.country&&g.country.length>0)
        html+='<span class=""lh-c"">'+g.country+'</span><span class=""lh-sep"">&#x2013;</span>';
      html+='<span class=""lh-n"">'+(g.league&&g.league.length>0?g.league:'TORNEO')+'</span>';
      html+='<span class=""lh-sport"">'+icon+'</span></div>';
      for(var j=0;j<g.matches.length;j++){
        var m=g.matches[j];
        total++;
        var scCls = m.isLive ? 'sc-live' : (m.tc==='ft' ? 'sc-ft' : 'sc-live');
        var scoreHtml = m.showScore
          ? '<div class=""sc-col""><span class=""'+scCls+'"">'+ m.score1+'</span><span class=""'+scCls+'"">'+m.score2+'</span></div>'
          : '<div class=""sc-col""><span class=""sc-ph"">-</span><span class=""sc-ph"">-</span></div>';
        html+='<div class=""mr""><div class=""tc"">'+buildTime(m)+'</div>';
        html+='<div class=""teams"">';
        html+='<div class=""team"">'+mkLogo(m.logo1,'lgo')+'<span class=""tn"">'+m.team1+'</span></div>';
        html+='<div class=""team"">'+mkLogo(m.logo2,'lgo')+'<span class=""tn"">'+m.team2+'</span></div>';
        html+='</div>'+scoreHtml;
        html+='<div class=""del"" onclick=""rm(\''+m.id+'\')"">&#x2715;</div></div>';
      }
      html+='</div>';
    }
  }
  document.getElementById('list').innerHTML=html;
  document.getElementById('cnt').textContent=total+(total===1?' partido':' partidos');
}
</script>
</body></html>";
    }
}
