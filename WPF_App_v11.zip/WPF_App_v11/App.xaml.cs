using System.Windows;

namespace WPFApp
{
    public partial class App : Application
    {
        private OverlayWindow? _overlayWindow;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Crear y mostrar la ventana de overlay
            _overlayWindow = new OverlayWindow();
            _overlayWindow.Show();

            // Ocultar ventana principal
            MainWindow?.Hide();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            _overlayWindow?.Close();
            base.OnExit(e);
        }
    }
}
