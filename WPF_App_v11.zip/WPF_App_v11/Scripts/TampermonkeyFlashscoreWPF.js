// ==UserScript==
// @name         Flashscore → WPF
// @namespace    http://tampermonkey.net/
// @version      25.0
// @description  Añade botón en Flashscore para enviar partidos a WPF App
// @author       WPFApp
// @match        https://www.flashscore.es/*
// @match        https://www.flashscore.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_addStyle
// @connect      localhost
// @connect      127.0.0.1
// @run-at       document-idle
// ==/UserScript==

(function () {
    'use strict';

    const WPF = "http://127.0.0.1:8765";
    let connected = false;

    GM_addStyle(`
        .wpf-btn {
            position:absolute; right:6px; top:50%; transform:translateY(-50%);
            width:24px; height:24px; border-radius:50%;
            background:#e8463c; color:white; border:none; cursor:pointer;
            font-size:10px; font-weight:bold; display:flex; align-items:center;
            justify-content:center; z-index:9999;
            box-shadow:0 2px 5px rgba(0,0,0,.5);
            transition:transform .15s,background .15s; line-height:1;
        }
        .wpf-btn:hover{background:#c0392b;transform:translateY(-50%) scale(1.15);}
        .wpf-btn.ok{background:#27ae60;}
        .wpf-toast{
            position:fixed;bottom:20px;right:20px;
            background:#111;color:#fff;padding:10px 16px;
            border-radius:6px;font-size:13px;font-weight:600;
            z-index:999999;box-shadow:0 4px 16px rgba(0,0,0,.5);
            border-left:3px solid #e8463c;pointer-events:none;
        }
        .wpf-toast.ok{border-color:#27ae60;}
        .wpf-toast.warn{border-color:#f39c12;}
        [data-event-row="true"]{position:relative!important;padding-right:36px!important;}
    `);

    function toast(msg, type = '') {
        const el = document.createElement('div');
        el.className = 'wpf-toast ' + type;
        el.textContent = msg;
        document.body.appendChild(el);
        setTimeout(() => el.remove(), 2800);
    }

    function checkConn() {
        GM_xmlhttpRequest({
            method: 'GET', url: WPF + '/health', timeout: 3000,
            onload: r => { connected = r.status === 200; },
            onerror: () => { connected = false; },
            ontimeout: () => { connected = false; }
        });
    }

    function safeClass(el) {
        try {
            var c = el.className;
            if (!c) return '';
            if (typeof c === 'string') return c;
            if (c.baseVal !== undefined) return c.baseVal;
            return '';
        } catch (e) { return ''; }
    }

    function norm(s) {
        try { return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().trim(); }
        catch (e) { return s.toUpperCase().trim(); }
    }

    function detectSport() {
        const path = window.location.pathname.toLowerCase();
        if (path.includes('baloncesto') || path.includes('basketball')) return 'basketball';
        if (path.includes('tenis') || path.includes('tennis')) return 'tennis';
        if (path.includes('hockey')) return 'hockey';
        if (path.includes('voleibol') || path.includes('volleyball')) return 'volleyball';
        if (path.includes('beisbol') || path.includes('baseball')) return 'baseball';
        if (path.includes('rugby')) return 'rugby';
        if (path.includes('futbol-americano') || path.includes('american-football')) return 'american-football';
        if (path.includes('balonmano') || path.includes('handball')) return 'handball';
        if (path.includes('futsal')) return 'futsal';
        return 'football';
    }

    // Claves en inglés (title del flag) Y español (texto del header), normalizadas
    var COUNTRY_CC = {
        // Español
        'ESPANA': 'es', 'SPAIN': 'es',
        'ALEMANIA': 'de', 'GERMANY': 'de',
        'INGLATERRA': 'gb-eng', 'ENGLAND': 'gb-eng',
        'FRANCIA': 'fr', 'FRANCE': 'fr',
        'ITALIA': 'it', 'ITALY': 'it',
        'PORTUGAL': 'pt',
        'HOLANDA': 'nl', 'NETHERLANDS': 'nl', 'HOLLAND': 'nl', 'PAISES BAJOS': 'nl',
        'BELGICA': 'be', 'BELGIUM': 'be',
        'TURQUIA': 'tr', 'TURKEY': 'tr',
        'BRASIL': 'br', 'BRAZIL': 'br',
        'ARGENTINA': 'ar',
        'ESTADOS UNIDOS': 'us', 'USA': 'us', 'UNITED STATES': 'us',
        'MEXICO': 'mx',
        'ESCOCIA': 'gb-sct', 'SCOTLAND': 'gb-sct',
        'GALES': 'gb-wls', 'WALES': 'gb-wls',
        'IRLANDA DEL NORTE': 'gb-nir', 'NORTHERN IRELAND': 'gb-nir',
        'ISRAEL': 'il',
        'AUSTRIA': 'at',
        'SUIZA': 'ch', 'SWITZERLAND': 'ch',
        'GRECIA': 'gr', 'GREECE': 'gr',
        'CROACIA': 'hr', 'CROATIA': 'hr',
        'SERBIA': 'rs',
        'UCRANIA': 'ua', 'UKRAINE': 'ua',
        'RUSIA': 'ru', 'RUSSIA': 'ru',
        'POLONIA': 'pl', 'POLAND': 'pl',
        'REPUBLICA CHECA': 'cz', 'CZECH REPUBLIC': 'cz', 'CZECHIA': 'cz',
        'DINAMARCA': 'dk', 'DENMARK': 'dk',
        'SUECIA': 'se', 'SWEDEN': 'se',
        'NORUEGA': 'no', 'NORWAY': 'no',
        'FINLANDIA': 'fi', 'FINLAND': 'fi',
        'RUMANIA': 'ro', 'ROMANIA': 'ro',
        'HUNGRIA': 'hu', 'HUNGARY': 'hu',
        'ESLOVAQUIA': 'sk', 'SLOVAKIA': 'sk',
        'BULGARIA': 'bg',
        'JAPON': 'jp', 'JAPAN': 'jp',
        'CHINA': 'cn',
        'COREA DEL SUR': 'kr', 'SOUTH KOREA': 'kr',
        'AUSTRALIA': 'au',
        'MARRUECOS': 'ma', 'MOROCCO': 'ma',
        'EGIPTO': 'eg', 'EGYPT': 'eg',
        'ARABIA SAUDI': 'sa', 'SAUDI ARABIA': 'sa',
        'COLOMBIA': 'co', 'CHILE': 'cl',
        'PERU': 'pe',
        'URUGUAY': 'uy', 'VENEZUELA': 've', 'ECUADOR': 'ec',
        'IRLANDA': 'ie', 'IRELAND': 'ie',
        'ALBANIA': 'al', 'ANDORRA': 'ad',
        'BOSNIA': 'ba', 'BOSNIA AND HERZEGOVINA': 'ba', 'BOSNIA Y HERZEGOVINA': 'ba',
        'CHIPRE': 'cy', 'CYPRUS': 'cy',
        'ESTONIA': 'ee',
        'LETONIA': 'lv', 'LATVIA': 'lv',
        'LITUANIA': 'lt', 'LITHUANIA': 'lt',
        'LUXEMBURGO': 'lu', 'LUXEMBOURG': 'lu',
        'MALTA': 'mt', 'MOLDOVA': 'md',
        'MONTENEGRO': 'me',
        'MACEDONIA DEL NORTE': 'mk', 'NORTH MACEDONIA': 'mk',
        'ESLOVENIA': 'si', 'SLOVENIA': 'si',
        'ISLANDIA': 'is', 'ICELAND': 'is',
        'KAZAJISTAN': 'kz', 'KAZAKHSTAN': 'kz',
        'ARMENIA': 'am',
        'AZERBAIYAN': 'az', 'AZERBAIJAN': 'az',
        'GEORGIA': 'ge',
        'IRAN': 'ir', 'IRAQ': 'iq',
        'JORDANIA': 'jo', 'JORDAN': 'jo',
        'LIBANO': 'lb', 'LEBANON': 'lb',
        'SIRIA': 'sy', 'SYRIA': 'sy',
        'EMIRATOS': 'ae', 'UAE': 'ae', 'UNITED ARAB EMIRATES': 'ae',
        'QATAR': 'qa', 'KUWAIT': 'kw',
        'INDIA': 'in', 'INDONESIA': 'id',
        'TAILANDIA': 'th', 'THAILAND': 'th',
        'VIETNAM': 'vn',
        'MALASIA': 'my', 'MALAYSIA': 'my',
        'FILIPINAS': 'ph', 'PHILIPPINES': 'ph',
        'SUDAFRICA': 'za', 'SOUTH AFRICA': 'za',
        'NIGERIA': 'ng', 'GHANA': 'gh', 'SENEGAL': 'sn',
        'CAMERUN': 'cm', 'CAMEROON': 'cm',
        'COSTA DE MARFIL': 'ci', 'IVORY COAST': 'ci',
        'TUNEZ': 'tn', 'TUNISIA': 'tn',
        'ARGELIA': 'dz', 'ALGERIA': 'dz',
        'CANADA': 'ca',
        'COSTA RICA': 'cr', 'PANAMA': 'pa',
        'HONDURAS': 'hn', 'GUATEMALA': 'gt', 'EL SALVADOR': 'sv',
        'BOLIVIA': 'bo', 'PARAGUAY': 'py',
        'NUEVA ZELANDA': 'nz', 'NEW ZEALAND': 'nz',
        'WORLD': 'world', 'MUNDO': 'world',
        'EUROPE': 'eu', 'EUROPA': 'eu',
    };

    function ccFromName(name) {
        var key = norm(name);
        if (COUNTRY_CC[key]) return COUNTRY_CC[key];
        for (var k in COUNTRY_CC) {
            if (key.indexOf(k) === 0 || k.indexOf(key) === 0) return COUNTRY_CC[k];
        }
        return '';
    }

    function parseHeader(hdr) {
        // ── LIGA ─────────────────────────────────────────────────────────
        var leagueEl = hdr.querySelector('[data-testid="wcl-scores-simple-text-01"][class*="bold"]');
        if (!leagueEl) leagueEl = hdr.querySelector('[data-testid="wcl-scores-simple-text-01"]');
        var leagueName = leagueEl ? leagueEl.textContent.trim() : '';

        // ── PAÍS: span.headerLeague__category-text (más limpio) ───────────
        var countryTextEl = hdr.querySelector('.headerLeague__category-text');
        var country = countryTextEl ? countryTextEl.textContent.trim() : '';
        // Fallback: wcl-scores-overline-05
        if (!country) {
            var overlineEl = hdr.querySelector('[data-testid="wcl-scores-overline-05"]');
            if (overlineEl) country = overlineEl.textContent.trim().replace(/:.*$/, '').trim();
        }

        var fullName = (country && leagueName) ? country + ' - ' + leagueName
            : (leagueName || country);

        // ── BANDERA: title del span.headerLeague__flag ───────────────────
        // <span class="headerLeague__flag icon--flag fl_97" title="Israel">
        var cc = '';
        var flagEl = hdr.querySelector('[class*="headerLeague__flag"]');
        if (flagEl) {
            var flagTitle = flagEl.getAttribute('title') || '';
            if (flagTitle) cc = ccFromName(flagTitle); // "Israel" → "il"
        }
        // Fallback: desde nombre del país en español
        if (!cc && country) cc = ccFromName(country);

        console.log('[HDR] ' + fullName + ' | cc=' + cc);
        return { leagueName: fullName, countryCode: cc };
    }

    function findLeagueAndCountry(row) {
        var sib = row.previousElementSibling;
        while (sib) {
            if (safeClass(sib).includes('headerLeague')) return parseHeader(sib);
            sib = sib.previousElementSibling;
        }
        var parent = row.parentElement;
        if (parent) {
            var children = Array.from(parent.children);
            var idx = children.indexOf(row);
            for (var i = idx - 1; i >= 0; i--) {
                if (safeClass(children[i]).includes('headerLeague')) return parseHeader(children[i]);
            }
        }
        var allHdrs = Array.from(document.querySelectorAll('[class*="headerLeague__wrapper"]'));
        var best = null;
        allHdrs.forEach(function (h) {
            if (row.compareDocumentPosition(h) & Node.DOCUMENT_POSITION_PRECEDING) best = h;
        });
        if (best) return parseHeader(best);
        return { leagueName: '', countryCode: '' };
    }

    function extract(row) {
        var team1 = '', team2 = '';
        var wcl = row.querySelectorAll('[data-testid="wcl-scores-simple-text-01"]');
        if (wcl.length >= 2) { team1 = wcl[0].textContent.trim(); team2 = wcl[1].textContent.trim(); }
        if (!team1) {
            team1 = row.querySelector('.event__participant--home')?.textContent?.trim() || '';
            team2 = row.querySelector('.event__participant--away')?.textContent?.trim() || '';
        }
        if (!team1) {
            var logos = row.querySelectorAll('[data-testid="wcl-participantLogo"]');
            team1 = logos[0]?.alt || ''; team2 = logos[1]?.alt || '';
        }

        var logoEls = row.querySelectorAll('[data-testid="wcl-participantLogo"]');
        var logo1 = logoEls[0]?.src || '', logo2 = logoEls[1]?.src || '';

        var status = '';
        var overline = row.querySelector('[data-testid="wcl-scores-overline"]');
        if (overline) status = overline.textContent.trim();
        if (!status) status = row.querySelector('.event__stage, .event__stage--block')?.textContent?.trim() || '';
        if (!status) status = row.querySelector('.event__time, [class*="event__time"]')?.textContent?.trim() || '';
        status = status.replace(/Preview/gi, '').replace(/Live Bet.*/gi, '').replace(/\s+/g, ' ').trim();

        var score1 = '', score2 = '';
        var wclScore = row.querySelectorAll('[data-testid="wcl-scores-simpleScore-01"]');
        if (wclScore.length >= 2) { score1 = wclScore[0].textContent.trim(); score2 = wclScore[1].textContent.trim(); }
        if (!score1) {
            score1 = row.querySelector('.event__score--home')?.textContent?.trim() || '';
            score2 = row.querySelector('.event__score--away')?.textContent?.trim() || '';
        }
        if (score1 === '-' || score1 === '–') score1 = '';
        if (score2 === '-' || score2 === '–') score2 = '';

        var info = findLeagueAndCountry(row);
        var link = row.querySelector('a[href*="/partido/"], a[href*="/match/"], a[href*="/game/"]');
        var matchLink = link ? link.href : '';
        var sport = detectSport();

        console.log('[WPF] ' + team1 + ' vs ' + team2 + ' | ' + info.leagueName + ' | cc=' + info.countryCode + ' | ' + status + ' | ' + score1 + '-' + score2);

        return {
            team1, team2, logo1, logo2, score1, score2, status,
            leagueName: info.leagueName, matchLink,
            countryCode: info.countryCode, sport
        };
    }

    function sendToWPF(data, btn) {
        if (!connected) { toast('⚠ WPF no disponible', 'warn'); return; }
        GM_xmlhttpRequest({
            method: 'POST', url: WPF + '/api/match',
            headers: { 'Content-Type': 'application/json' },
            data: JSON.stringify(data), timeout: 4000,
            onload: r => {
                if (r.status === 200) {
                    toast('✓ Enviado a WPF', 'ok');
                    btn.classList.add('ok');
                    setTimeout(() => btn.classList.remove('ok'), 1500);
                } else { toast('✗ Error ' + r.status); }
            },
            onerror: () => toast('✗ Sin conexión'),
            ontimeout: () => toast('✗ Timeout')
        });
    }

    function addButtons() {
        document.querySelectorAll('[data-event-row="true"]').forEach(row => {
            if (row.querySelector('.wpf-btn')) return;
            var btn = document.createElement('button');
            btn.className = 'wpf-btn'; btn.textContent = '▶'; btn.title = 'Enviar a WPF';
            btn.addEventListener('click', function (e) {
                e.stopPropagation(); e.preventDefault();
                sendToWPF(extract(row), btn);
            });
            row.appendChild(btn);
        });
    }

    checkConn();
    setInterval(checkConn, 10000);
    setInterval(addButtons, 2000);
    addButtons();
    new MutationObserver(() => addButtons())
        .observe(document.body, { childList: true, subtree: true });

})();
