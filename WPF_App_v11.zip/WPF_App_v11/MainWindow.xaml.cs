using System;
using System.Windows;
using System.Windows.Media;
using WPFApp.Services;

namespace WPFApp
{
    public partial class MainWindow : Window
    {
        private OverlayWindow? _overlay;
        private LocalServerService _server = new();

        public MainWindow()
        {
            InitializeComponent();
            _ = StartServer();
        }

        private async System.Threading.Tasks.Task StartServer()
        {
            bool ok = await _server.StartAsync();
            _server.OnMatchDataReceived += OnMatchReceived;

            Dispatcher.Invoke(() =>
            {
                if (ok)
                {
                    StatusDot.Fill  = new SolidColorBrush(Color.FromRgb(0x28, 0xa7, 0x45));
                    StatusText.Text = $"Activo :{_server.Port}";
                    BtnServerStatus.Content = $"● Servidor activo en :{_server.Port}";
                }
                else
                {
                    StatusDot.Fill  = new SolidColorBrush(Colors.Red);
                    StatusText.Text = "Error al iniciar servidor";
                }
            });
        }

        private void OnMatchReceived(object? sender, LocalServerService.MatchDataEventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                if (_overlay == null || !_overlay.IsVisible)
                {
                    _overlay = new OverlayWindow(_server);
                    _overlay.Show();
                }
                _overlay.AddMatch(e);
                _overlay.Activate();
            });
        }

        private void OpenOverlay_Click(object sender, RoutedEventArgs e)
        {
            if (_overlay == null || !_overlay.IsVisible)
            { _overlay = new OverlayWindow(_server); _overlay.Show(); }
            else _overlay.Activate();
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            _server.Stop();
            _overlay?.Close();
            Application.Current.Shutdown();
        }

        private void TitleBar_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
            => DragMove();
    }
}
