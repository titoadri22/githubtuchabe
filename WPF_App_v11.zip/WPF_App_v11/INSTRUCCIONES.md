# WPF Flashscore App v11

## Archivos modificados/nuevos
- `MainWindow.xaml` + `MainWindow.xaml.cs` → Panel de control reescrito
- `OverlayWindow.xaml` + `OverlayWindow.xaml.cs` → Overlay completo estilo Flashscore
- `Scripts/TampermonkeyFlashscoreWPF.js` → Script Tampermonkey v11
- `Services/LocalServerService.cs` → Sin cambios importantes

## Cómo usar
1. Compila y ejecuta la app WPF (`dotnet run` o Visual Studio)
2. Se abre el panel de control con "Servidor activo en :8765"
3. Pulsa **⚡ Abrir Overlay Flashscore** para abrir la ventana
4. En el navegador, instala el script JS en Tampermonkey
5. Ve a flashscore.es → aparece un botón ▶ rojo en cada partido
6. Pulsa ▶ → el partido aparece en el overlay con tiempo en vivo

## Tiempo en directo
- Si el partido está en curso (marca minutos como "45'"), el contador sube automáticamente cada segundo
- HT = pausado en 45:00
- FT = detenido, muestra FT

## Funciones del overlay
- Click en un partido del sidebar → ver detalle con marcador grande
- × en una fila → eliminar partido
- ⊗ en titlebar → eliminar todos
- Drag desde titlebar → mover ventana
- "Ver en Flashscore →" → abre el partido en el navegador
